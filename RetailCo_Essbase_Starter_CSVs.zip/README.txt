
RetailCo Essbase Starter CSVs
============================

This package contains sample metadata and data files for an intermediate Hyperion Essbase practice project.

Files
-----
- accounts.csv — Account hierarchy (parent-child) with aggregation operators and UDAs.
- entity.csv — Entity hierarchy including APAC (India) and EMEA (UK) plus HQ.
- product.csv — Product hierarchy with Apparel and Electronics and leaf SKUs.
- channel.csv — Channel hierarchy.
- attributes_product.csv — Product attribute dimension mappings (color, season).
- attributes_store.csv — Store attribute dimension mappings (size, tier).
- actuals_FY2025.csv — Monthly Actuals (Apr–Mar FY2025) in local currency (INR/GBP) at leaf intersections.
- fx_rates_to_USD_FY2025.csv — Monthly average FX rates mapping INR/GBP/EUR to USD.
- budget_seed_FY2026_Q1.csv — Example Budget.Working seed for three months (Apr–Jun FY2026).

Notes
-----
- Fiscal year assumed to start in April (Apr–Mar).
- Currency is stored at the data row in local currency for each entity; conversion to reporting currency (e.g., USD) should be handled in calc logic.
- Hierarchies are provided in parent-child format suitable for dimension build rules.
- You can expand rows by adding more SKUs, entities, or months following the same schemas.
